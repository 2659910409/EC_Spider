#! python3
# -*-coding: utf-8-*-

import pyautogui
import settings
import socket
import os
import psutil
from sqlalchemy import create_engine
import json
from urllib import request
import logging
import time
import pymysql

logging.getLogger("requests").setLevel(logging.WARNING)
file_path = 'C:/wangwangfenliu/log/'

file_name = file_path + time.strftime('%Y-%m-%d', time.localtime(time.time()))

logging.basicConfig(level=logging.INFO,
                    filename='{}.log'.format(file_name),
                    filemode='a',
                    format='%(asctime)s-%(levelname)s-%(funcName)s-%(lineno)d:%(message)s'
                    )


def screenshot_images(shopname, errorname):
    path = time.strftime('%Y-%m-%d', time.localtime(time.time()))
    images_dir = settings.ERROR_IMAGES_DIR + path + '/' + shopname + '/'
    if not os.path.exists(images_dir):
        os.makedirs(images_dir)
    image_name = errorname + time.strftime('_%H_%M_%S', time.localtime(time.time())) + '.png'
    print(images_dir+image_name)
    pyautogui.screenshot(imageFilename=images_dir + image_name)


def init_db():
    engine = create_engine(
        # TODO 数据库地址
        settings.MYSQL_LINK_STR,
        max_overflow=1,
        pool_size=1,
        pool_timeout=30,
        pool_recycle=-1
    )
    conn = engine.raw_connection()
    csr = conn.cursor()
    return conn, csr


def init_or_db():
    conn = pymysql.connect(host=settings.MYSQL_CONFIG['host'],
                           port=settings.MYSQL_CONFIG['port'],
                           user=settings.MYSQL_CONFIG['user'],
                           password=settings.MYSQL_CONFIG['password'],
                           database=settings.MYSQL_CONFIG['database'],
                           charset=settings.MYSQL_CONFIG['charset'])
    csr = conn.cursor()
    return conn, csr


def insert_console_log(conn, csr, leavel, ip, log):
    insert_sql = """insert into console_log(ip,leavel,log,created) values ('{}','{}','{}',now())""".format(ip, leavel,
                                                                                                           log)
    csr.execute(insert_sql)
    conn.commit()


def insert_log(conn, csr, leavel, log):
    insert_sql = """insert into run_log (leavel,log,created) values ('{}','{}',now())""".format(leavel, log)
    csr.execute(insert_sql)
    conn.commit()


def upgrade_status(conn, csr, status, shopname):
    log = settings.STATUS_LOG[status]
    upgrade_status_sql = "update shops set shop_status ={} ,log = '{}' where shopname = '{}'".format(status, log,
                                                                                                     shopname)
    csr.execute(upgrade_status_sql)
    # print(upgrade_status_sql)
    conn.commit()


def check_port(port, ports, ip='127.0.0.1'):
    if port in ports:
        return False
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    return s.connect_ex((ip, port))


def get_port(csr):
    find_port_sql = """select chrome_port from shops where is_start = 0 """
    csr.execute(find_port_sql)
    ports = []
    port_tuples = csr.fetchall()
    if port_tuples:
        for port_tuple in port_tuples:
            if port_tuple:
                ports.append(port_tuple[0])
    port = 9000
    while not check_port(port, ports):
        port += 1
        if port > 60000:
            raise Exception
    return port


def test_process(process):
    if process:
        return psutil.pid_exists(process)


def close_process(process):
    if process:
        if test_process(process):
            try:
                os.kill(process, 9)
            except Exception as e:
                logging.error('关闭进程错误，错误信息：{}'.format(e))


def sendDingDingMessage(posturl, title, text):
    """发送钉钉消息"""
    text = title + '\n' + text
    # 群：爬虫系统开发
    data = {"msgtype": "text", "text": {"content": text}, "at": {"atMobiles": [], "isAtAll": False}}
    data = json.dumps(data)
    data = bytes(data, 'utf-8')
    req = request.Request(posturl, headers={"Content-Type": "application/json; charset=utf-8"})
    response = request.urlopen(req, data)
    return response.read()


def write_local_log(level, ip, log):
    now_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    with open('console.log', 'a') as f:
        f.write('{}-{}-{}-{}\n'.format(now_time, level, ip, log))

