
from time import sleep
from  multiprocessing import Pool,Manager
from threading import Thread
import os
from subprocess import Popen

url_list =['https://www.baidu.com/','https://www.taobao.com/','https://www.jd.com/']

class Ptest():
    def __init__(self,p_num):
        self.p_num = p_num

    def run(self):
        #  --proxy-server=127.0.0.1:8080
        access =  '"chrome" --user-data-dir="C:\wangwangfenliu\\users\{}" --start-maximized --remote-debugging-port={}'.format(self.p_num,self.p_num)
        Popen(access)
        sleep(3)
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        chrome_options = Options()
        chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:{}".format(self.p_num))
        sleep(5)
        self.driver = webdriver.Chrome(chrome_options=chrome_options)
        print(self.p_num)
        self.driver.maximize_window()
        self.driver.implicitly_wait(20)
        for url in url_list:
            self.driver.get(url)
            sleep(3)
        # schedule.every(1).seconds.do(self.task)
        # while True:
        #     schedule.run_pending()
        #     sleep(1)

    def task(self):
        print(os.getpid(), self.p_num)


def th_test1():
    for i in range(100):
        print(i)
        sleep(1)

def p_test(p_num):
    test = Ptest(p_num)
    test.run()

def th_test2(pool,q):
    for i in range(9000,9003):
        pool.apply_async(p_test, (i,))


if __name__ == '__main__':
    pool = Pool()

    q = Manager().Queue()
    # t1 = Thread(target=th_test1,)
    t2 = Thread(target=th_test2,args=(pool,q))
    # t1.start()
    t2.start()
    pool.close()
    pool.join()
