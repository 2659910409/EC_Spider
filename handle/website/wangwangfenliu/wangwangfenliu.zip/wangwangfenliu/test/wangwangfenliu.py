#! python3
# -*-coding: utf-8-*-

import pyautogui
from pywinauto.findwindows import find_windows

import logging
import os
import ctypes

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from multiprocessing import Manager, Pool
from threading import Thread
from timeout3 import timeout
from retry import retry
from time import sleep

import settings
import utils
import pymssql
import pymysql
import subprocess
import os

# 店铺信息 shopname: status,profile,handle,task_pid,chrome_pid
config = {}
# 所有端口
ports = []
# 所有任务
tasks = []


class TaskShop():

    def __init__(self):
        pass

    def run(self):
        pass


def task_start_shop(task, pool, q):
    pass


def task_monitor(q):
    # 监控chrome_pid is alive
    pass


def manger_add_task(shopname):
    tasks.append(shopname)


def control_add_tasks(shopname='all'):
    shops = utils.get_shop_config(shopname)
    for shop in shops:
        config[shop[1]] = [0, shop[2], None, None,None,None]
        manger_add_task(shop[1])


def control_main():
    # 1. 添加任务到 task中
    # 2. 循环获取输入内容
    # 3. 分解输入，做相应的处理
    control_add_tasks()
    while True:
        control_words = input('请输入控制指令,输入help,获取帮助信息')
        words_list = control_words.split()
        if len(words_list) == 1:
            if words_list[0] == 'help':
                print(settings.HELP_WORDS)
            elif words_list[0] == 'shops':
                # 返回所有店铺信息
                pass
            elif words_list[0] == 'quit':
                # 关闭所有子进程和浏览器，并退出
                pass
            else:
                print('error command words ! ')

        elif len(words_list) == 2:
            if words_list[0] == 'restart':
                # 根据店铺名来重启店铺
                pass
            elif words_list[0] == 'close':
                # 关闭店铺
                pass
            else:
                print('error command words ! ')
        else:
            print('error command words ! ')


def manger_main(pool, q):
    # 循环读取tasks 列表 启动浏览器
    # 任务的监控
    while True:
        if tasks:
            task_start_shop(tasks[0], pool, q)
        if not q.empty():
            for msg in range(q.qsize()):
                print(q.get_nowait())
                # todo 做相应的处理 ，将
        task_monitor(q)
        sleep(2)


if __name__ == '__main__':
    pool = Pool()
    q = Manager().Queue()
    t1 = Thread(target=control_main)
    t1.start()
    sleep(0.5)
    t2 = Thread(target=manger_main, args=(pool, q))
    t2.start()
