from selenium import webdriver
# -*- coding: utf-8 -*-
import time
import datetime
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC

# login_url = "https://login.taobao.com/member/login.jhtml"
# driver = webdriver.Chrome()
# driver.get(login_url)


# # load in the javascript to inject
# with open('./test_chrome_driver/tb.js', 'r') as f:
#     content_js = f.read()

# 启动chrome浏览器，返回chrome
def get_chrome_browser():
    option = webdriver.ChromeOptions()
    option.add_experimental_option('excludeSwitches', ['enable-automation'])
    option.add_argument('--proxy-server=http://127.0.0.1:8080')
    browser = webdriver.Chrome(options=option, chrome_options=option)
    browser.implicitly_wait(30)
    return browser


login_url = "https://login.taobao.com/member/login.jhtml"
driver = get_chrome_browser()
driver.get(login_url)
