# a= 'qqwd sacs   qfds'
# print(a.split())
# a= [1,2,None,None]
# print(a)
# b = 0
# for i in a:
#     b+=1
#     print(b)
# a = [1,2,3]
# print(str(a))
# import psutil
# p = psutil.Process()
# print(p.status())
# cols = ["crawl_time","shop_id","shop_nick","value1","value2","value3","value4","value5","value6",]
# cols_str = ','.join(cols)
# print(cols_str)
# import pyautogui
from time import sleep

# def wait_load_ok():
#     mark = True
#     i = 0
#     while mark:
#         try:
#             rect =
#             mark = False
#             return rect
#         except:
#             i += 1
#             print(i)
#             sleep(1)  region=(1150, 200, 400, 400),confidence=0.8
# import redis
#
# r = redis.Redis(host='localhost', port=6379, db=0)
# r.set('foo', 'bar')
# print(r.get('foo'))
from pywinauto.findwindows import find_windows
chrome = find_windows(class_name='Chrome_WidgetWin_1')
print(type(chrome))
print(chrome)