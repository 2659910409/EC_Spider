# -*- coding:utf8 -*-
# ! python3

from flask import Flask, render_template, jsonify, request
from sqlalchemy import create_engine
import settings
import utils
from subprocess import Popen
from datetime import datetime
from threading import Thread

engine = create_engine(
    # TODO 数据库地址
    settings.MYSQL_LINK_STR,
    max_overflow=0,
    pool_size=5,
    pool_timeout=30,
    pool_recycle=3600
)

app = Flask(__name__)


def shops_data():
    time_now = datetime.now()
    datas = []
    conn = engine.raw_connection()
    csr = conn.cursor()
    get_all_shop_state = """select shopname,start_time,is_active,service_status, shop_status from shops"""
    csr.execute(get_all_shop_state)
    shops_d = csr.fetchall()
    # print(shops_d)
    csr.close()
    conn.close()
    for shop_data in shops_d:
        data = []
        data.append(shop_data[0])
        data.append(shop_data[1])
        if shop_data[4] == 0:
            data.append('等待启动')
        elif shop_data[4] == 1:
            data.append('正在启动')
        elif shop_data[4] == 2:
            data.append('正常运行')
        elif shop_data[4] == 3:
            data.append('操作店小蜜')
        elif shop_data[4] == 4:
            data.append('正常关闭')
        else:
            data.append('异常结束')
        second_num = int((time_now - shop_data[1]).seconds)
        day_num, a = divmod(second_num, 3600 * 24)
        hours_num, b = divmod(a, 3600)
        minute_num, c = divmod(b, 60)
        text = ''
        if hours_num:
            text = '{}小时'.format(hours_num) + text
            if day_num:
                text = '{}天'.format(day_num) + text
        text = text + '{}分'.format(minute_num)
        data.append(text)
        if shop_data[3] == 0:
            data.append('尚未获取')
        elif shop_data[3] == 1:
            data.append('人工优先')
        elif shop_data[3] == 2:
            data.append('助手优先')
        elif shop_data[3] == 3:
            data.append('混合接待')
        data.append(shop_data[2])
        datas.append(data)
    # print(datas)
    return datas


@app.route('/web_console/')
def console():
    return render_template('console1.html', datas=shops_data())


@app.route('/close/<shopname>/')
def close_shop(shopname):
    print('close shop', shopname)
    ip = request.remote_addr
    conn = engine.raw_connection()
    csr = conn.cursor()
    status_log = settings.STATUS_LOG[4]
    if shopname == 'all':
        get_active_shops_sql = """select shopname from shops where is_active = 0"""
        csr.execute(get_active_shops_sql)
        shopnames = csr.fetchall()
        if shopnames:
            close_shop_sql = """update shops set is_active = 1,shop_status = 4,log='{}'where is_active = 0""".format(
                status_log)
            csr.execute(close_shop_sql)
            conn.commit()
            utils.write_local_log('warning', ip, '关闭的店铺列表为：{}'.format(shopnames))
    else:
        close_shop_sql = """update shops set is_active = 1,shop_status = 4,log='{}' where shopname = '{}'""".format(
            status_log, shopname)
        csr.execute(close_shop_sql)
        conn.commit()
        utils.write_local_log('warning', ip, '关闭的店铺为：{}'.format(shopname))
    csr.close()
    conn.close()
    return render_template('console1.html', datas=shops_data())


def start_manger():
    print('start manger')
    Popen('python manger.py')


@app.route('/start/<shopname>/')
def start_shop(shopname):
    print('start shop', shopname)
    ip = request.remote_addr
    conn = engine.raw_connection()
    csr = conn.cursor()
    # 获取所有已启动店铺店铺
    get_all_is_active_shop_sql = """select shopname from shops where is_active = 0"""
    csr.execute(get_all_is_active_shop_sql)
    all_shop_state = csr.fetchall()
    if shopname == 'all':
        # 获取所有设置为启动，目前关闭的店铺
        get_closed_shops_sql = """select shopname from shops where is_active = 1 and is_start = 0"""
        csr.execute(get_closed_shops_sql)
        shopnames = csr.fetchall()
        if shopnames:
            start_shop_sql = """update shops set is_active = 0,shop_status = 0 where is_active = 1 and is_start = 0 """
            csr.execute(start_shop_sql)
            conn.commit()
            utils.write_local_log('info', ip, '开启的的店铺列表为：{}'.format(shopnames))
    else:
        start_shop_sql = """update shops set is_active = 0 ,shop_status = 0 where shopname = '{}'""".format(shopname)
        csr.execute(start_shop_sql)
        conn.commit()
        utils.write_local_log('info', ip, '开启的的店铺为：{}'.format(shopname))
    csr.close()
    conn.close()
    if not all_shop_state:
        t = Thread(target=start_manger)
        t.start()
    return render_template('console1.html', datas=shops_data())


# 获取数据
def getData(sql):
    results = []
    # 打开数据库连接
    db = engine.raw_connection()
    # 使用cursor()方法获取操作游标
    cursor = db.cursor()

    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        for result in cursor.fetchall():
            single = []
            for i in range(9):
                if i == 6:
                    if result[6] is not None:
                        if result[3]:
                            single.append(round(result[6] / result[3], 1))
                            single.append(round(result[2] / result[3], 1))
                        else:
                            single.append(0.0)
                            single.append(0.0)
                    else:
                        single.append('')
                        single.append('')
                    continue
                if i == 8:
                    if result[8] == 0:
                        single.append('尚未获取')
                    elif result[8] == 1:
                        single.append('人工优先')
                    elif result[8] == 2:
                        single.append('助手优先')
                    elif result[8] == 3:
                        single.append('混合接待')
                    continue
                if result[i] is not None:
                    single.append(result[i])
                else:
                    single.append('')
            results.append(single)
    except Exception as e:
        print("Error: unable to fetchall data")
        print(e)
    db.close()
    return results


@app.route('/')
def index():
    # SQL 查询语句
    last_time_sql = """select crawl_time from crawl_custom_service WHERE id = (SELECT MAX(id) FROM crawl_custom_service);"""
    detail_sql = """
SELECT
t1.shop_type,
t1.shop_show,
t2.value1,
t2.value2,
t2.value3,
t2.value4,
t2.value6,
t1.category,
t1.service_status
FROM shops as t1
LEFT JOIN fe t2 ON t1.shopname = t2.shop_nick ORDER BY t1.sort;"""
    details = []
    Make_up = []
    Skin_A = []
    Skin_B = []
    Skin_C = []
    Derma = []
    db = engine.raw_connection()
    # 使用cursor()方法获取操作游标
    cursor = db.cursor()
    cursor.execute(last_time_sql)
    last_time = cursor.fetchone()[0]
    for data in getData(detail_sql):
        if data[6] and float(data[6]) > 30 and float(data[6]) <= 60:
            v5_flag1 = True
        else:
            v5_flag1 = False
        if data[6] and float(data[6]) > 60:
            v5_flag2 = True
        else:
            v5_flag2 = False
        if data[7] and float(data[7]) > 20:
            v6_flag1 = True
        else:
            v6_flag1 = False
        if data[7] and float(data[7]) > 10 and float(data[7]) > 10:
            v6_flag2 = True
        else:
            v6_flag2 = False
        if data[8] == 'Make Up':
            Make_up.append(
                {'class1': data[0], 'class2': data[1], 'value1': data[2], 'value2': data[3], 'value3': data[4],
                 'value4': data[5], 'value5': data[6], 'value6': data[7],
                 'service_status': data[9], 'v6_flag2': v6_flag2,
                 'v5_flag1': v5_flag1, 'v5_flag2': v5_flag2, 'v6_flag1': v6_flag1})
        elif data[8] == 'Skin Care(A)':
            Skin_A.append(
                {'class1': data[0], 'class2': data[1], 'value1': data[2], 'value2': data[3], 'value3': data[4],
                 'value4': data[5], 'value5': data[6], 'value6': data[7],
                 'service_status': data[9], 'v6_flag2': v6_flag2,
                 'v5_flag1': v5_flag1, 'v5_flag2': v5_flag2, 'v6_flag1': v6_flag1})
        elif data[8] == 'Skin Care(B)':
            Skin_B.append(
                {'class1': data[0], 'class2': data[1], 'value1': data[2], 'value2': data[3], 'value3': data[4],
                 'value4': data[5], 'value5': data[6], 'value6': data[7],
                 'service_status': data[9], 'v6_flag2': v6_flag2,
                 'v5_flag1': v5_flag1, 'v5_flag2': v5_flag2, 'v6_flag1': v6_flag1})
        elif data[8] == 'Skin Care(C)':
            Skin_C.append(
                {'class1': data[0], 'class2': data[1], 'value1': data[2], 'value2': data[3], 'value3': data[4],
                 'value4': data[5], 'value5': data[6], 'value6': data[7],
                 'service_status': data[9], 'v6_flag2': v6_flag2,
                 'v5_flag1': v5_flag1, 'v5_flag2': v5_flag2, 'v6_flag1': v6_flag1})
        elif data[8] == 'Derma':
            Derma.append({'class1': data[0], 'class2': data[1], 'value1': data[2], 'value2': data[3], 'value3': data[4],
                          'value4': data[5], 'value5': data[6], 'value6': data[7],
                          'service_status': data[9], 'v6_flag2': v6_flag2,
                          'v5_flag1': v5_flag1, 'v5_flag2': v5_flag2, 'v6_flag1': v6_flag1})
    Make_up.insert(0, {'shopnums': len(Make_up), 'category': 'Make Up'})
    Skin_A.insert(0, {'shopnums': len(Skin_A), 'category': 'Skin Care(A)'})
    Skin_B.insert(0, {'shopnums': len(Skin_B), 'category': 'Skin Care(B)'})
    Skin_C.insert(0, {'shopnums': len(Skin_C), 'category': 'Skin Care(C)'})
    Derma.insert(0, {'shopnums': len(Derma), 'category': 'Derma'})
    details.append(Make_up)
    details.append(Skin_A)
    details.append(Skin_B)
    details.append(Skin_C)
    details.append(Derma)
    # print("entries:", entries)
    # print("details:", details)
    return render_template('index.html', last_time=last_time, details=details)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
