# from selenium import webdriver
# from selenium.webdriver.chrome.options import Options
# from time import sleep
# # "chrome" --proxy-server=172.16.50.75:8080 --start-maximized https://sycm.taobao.com/portal/home.htm --user-data-dir="C:/wangwangfenliu/users/AC" --remote-debugging-port=9333
# # port = 9333
# shop_service_url = 'https://zizhanghao.taobao.com/subaccount/qianniu/setting.htm'
#
# shop_main_url = 'https://zizhanghao.taobao.com/subaccount/qianniu/realTime.htm'
#
# chrome_options = Options()
# chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:{}".format(port))
# driver = webdriver.Chrome(chrome_options=chrome_options)
#
#
# def check_load_page_ready():
#     while True:
#         try:
#             driver.find_element_by_xpath("//div[@class='accept_model service_helper_item']")
#             return
#         except:
#             sleep(1)
#
#
# def double_check( button=1):
#     driver.get(shop_main_url)
#     sleep(1)
#     driver.get(shop_service_url)
#     select_xpath_str = "//div[@class='accept_model service_helper_item']/div[@class = 'helper_item_container']/div[{}]/input".format(
#         button)
#     return driver.find_element_by_xpath(select_xpath_str).is_selected()
#
#
# def select_button(button=1):
#     # todo 下拉动作
#     select_xpath_str = "//div[@class='accept_model service_helper_item']/div[@class = 'helper_item_container']/div[{}]/input".format(
#         button)
#     driver.find_element_by_xpath(select_xpath_str).click()
#     sleep(1)
#     driver.find_element_by_xpath("//div[@class = 'section-group']/button").click()
#     sleep(1)
#
#
# def check_action_success():
#     get_text_xpath_str = "//div[@class = 'sui-msg msg-large msg-success']/div"
#     text = driver.find_element_by_xpath(get_text_xpath_str).text
#     return '成功' in text
#
#
# def start_shop_service():
#     driver.get(shop_service_url)
#     check_load_page_ready()
#     if double_check(1):
#         # TODO warning people
#         return
#     sleep(1)
#     select_button(1)
#     if not check_action_success():
#         # TODO warning people
#         raise Exception
#     if not double_check(1):
#         # TODO warning people
#         raise Exception

# import utils
# from settings import DingDingGroupURL
# conn,csr = utils.init_db()

# def send_shop_service_report():
#     select_sql = """select shopname, shop_service_status from shops"""
#     csr.execute(select_sql)
#     shop_service_status = csr.fetchall()
#     dont_handle_text = ''
#     error_text = ''
#     warning_text = ''
#     normal_text = ''
#     for shop_info in shop_service_status:
#         if shop_info[1] == 0:
#             dont_handle_text = dont_handle_text + shop_info[0] + '\n'
#         elif shop_info[1] == 1 or shop_info[1] == 4:
#             normal_text = normal_text + shop_info[0] + '\n'
#         elif shop_info[1] == 2 or shop_info[1] == 5:
#             warning_text = warning_text + shop_info[0] + '\n'
#         elif shop_info[1] == 3 or shop_info[1] == 6:
#             error_text = error_text + shop_info[0] + '\n'
#     title = '旺旺分流告警'
#     text = '未处理的店铺：\n{}\n处理失败的店铺：\n{}\n处理前已在特定状态的店铺：\n{}\n处理成功的店铺：\n{}'.format(dont_handle_text, error_text,
#                                                                                warning_text, normal_text)
#     # logging.info('旺旺分流-店小蜜告警信息：{}'.format(text))
#     utils.sendDingDingMessage(DingDingGroupURL, title, text)
#     update_sql = """update shops set shop_service_status = 0"""
#     csr.execute(update_sql)
#     conn.commit()
#     # logging.info('已将店小蜜状态更新未0')

# if __name__ == '__main__':
#     send_shop_service_report()



# a = datetime.now()
# b = datetime.strptime('2019-05-3117:36:11', '%Y-%m-%d%H:%M%S')
#
# print((a - b).seconds)
from decimal import Decimal
# [15864698, 21500118, 5047716, 6033942, 17830408, 5640016, 4789352, 6885366]
from pywinauto.findwindows import find_windows
print(find_windows(class_name='Chrome_WidgetWin_1'))
