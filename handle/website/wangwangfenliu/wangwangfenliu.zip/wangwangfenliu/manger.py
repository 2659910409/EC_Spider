# -*- coding:utf-8 -*-
# ! python3

from multiprocessing import Pool
from time import sleep
from spider import Spider
from subprocess import Popen
from settings import ACCESS, DingDingGroupURL, DingDingInsideGroupURL
import utils
from pywinauto.findwindows import find_windows
from retry import retry
from timeout3 import timeout
import ctypes
import pyautogui
from random import randint, uniform
from datetime import datetime
import schedule
import logging
from pygetwindow._pygetwindow_win import Win32Window

pyautogui.FAILSAFE = False

SHOP_START_RETRY_TIMES = {}


def new_shop(shop_info, port):
    spider = Spider(shop_info[0], port)
    spider.run()


def update_port(shopname, port):
    update_port_sql = """update shops set chrome_port = {} where shopname = '{}'""".format(port, shopname)
    csr.execute(update_port_sql)
    conn.commit()


def warning_people_to_handle_login(shopname):
    title = '旺旺分流告警：'
    text = '店铺：{}\n' \
           '登录出现异常，请求人工处理！'.format(shopname)
    utils.screenshot_images(shopname, '登录出现异常，请求人工处理！')
    utils.sendDingDingMessage(DingDingGroupURL, title, text)
    utils.sendDingDingMessage(DingDingInsideGroupURL, title, text)


def start_shop(shop_info):
    try:
        times = SHOP_START_RETRY_TIMES[shop_info[0]]
    except:
        SHOP_START_RETRY_TIMES[shop_info[0]] = 0
        times = 0
    port = utils.get_port(csr)
    logging.info('获取端口,店铺：{},端口：{}'.format(shop_info[0], port))
    update_port(shop_info[0], port)
    tao = TaoLogin(shop_info, shop_info[0], port)
    try:
        logging.info('开始登录店铺：{}'.format(shop_info[0]))
        try:
            tao.run()
        except Exception as e:
            if times < 3:
                raise e
            else:
                logging.info('登录店铺失败，将会转为手动登录')
                # TODO SEND WAIT PEOPLE HANDLE LOGIN
                warning_people_to_handle_login(shop_info[0])
        logging.info('登录店铺成功,将开启一个新进程来接管店铺操作')
        pool.apply_async(new_shop, (shop_info, port))
        SHOP_START_RETRY_TIMES[shop_info[0]] = 0
        logging.info('新进程开启成功')
    except:
        logging.error('店铺启动失败：{}'.format(shop_info[0]))
        utils.screenshot_images(shop_info[0], '店铺启动失败')
        SHOP_START_RETRY_TIMES[shop_info[0]] += 1
        title = '旺旺分流告警'
        text = '店铺:{},\n' \
               '时间:{},\n' \
               '登录失败，将暂停店铺登录'.format(shop_info[0], datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        utils.sendDingDingMessage(DingDingGroupURL, title, text)
        utils.sendDingDingMessage(DingDingInsideGroupURL, title, text)
        utils.upgrade_status(conn, csr, 0, shop_info[0])
        logging.info('店铺失败，已发送钉钉告警以及将店铺状态重新设置为0')
    logging.info('开启店铺成功,{}'.format(shop_info[0]))


def close_shop(shop_info):
    utils.close_process(shop_info[3])
    utils.close_process(shop_info[4])
    if shop_info[2]:
        try:
            ctypes.windll.user32.PostMessageA(shop_info[2], 0x0010, 0, 0)
        except Exception as e:
            logging.error('关闭chrome窗口句柄出现错误，错误信息：{}'.format(e))
            utils.screenshot_images(shop_info[0], '关闭chrome窗口句柄出现错误')
            # print(e)
            pass


def get_shops_info():
    # 获取所有店铺信息
    get_shops_info_sql = """select shopname,shop_status,handle,chrome_pid,manger_pid,is_active,is_start,user_dir,chrome_port,refresh_time from shops"""
    conn.commit()
    csr.execute(get_shops_info_sql)
    result = csr.fetchall()
    return result


def upgrade_active(shopname, status):
    upgrade_active_sql = "update shops set is_active ={} where shopname = '{}'".format(status, shopname)
    csr.execute(upgrade_active_sql)
    conn.commit()


def get_shops_data_time():
    get_shop_data_sql = """select distinct shop_nick from crawl_custom_service where crawl_time >= now()-interval 3 MINUTE"""
    csr.execute(get_shop_data_sql)
    shops_info = csr.fetchall()
    shops = []
    if shops_info:
        for shop in shops_info:
            shops.append(shop[0])
    # print('get data:', shops_info)
    return shops


def get_all_chrome_handle():
    return find_windows(class_name='Chrome_WidgetWin_1')


def close_main():
    get_active_shop_sql = """select shopname from shops where is_active = 0 and shop_status != 4"""
    csr.execute(get_active_shop_sql)
    return csr.fetchall()


def monitor_chrome_handle():
    # TODO
    pass


def send_shop_service_report(task='start'):
    select_sql = """select shopname, shop_service_status from shops"""
    csr.execute(select_sql)
    shop_service_status = csr.fetchall()
    dont_handle_text = ''
    error_text = ''
    warning_text = ''
    normal_text = ''
    for shop_info in shop_service_status:
        if shop_info[1] == 0:
            dont_handle_text = dont_handle_text + shop_info[0] + '\n'
        elif shop_info[1] == 1 or shop_info[1] == 4:
            normal_text = normal_text + shop_info[0] + '\n'
        elif shop_info[1] == 2 or shop_info[1] == 5:
            warning_text = warning_text + shop_info[0] + '\n'
        elif shop_info[1] == 3 or shop_info[1] == 6:
            error_text = error_text + shop_info[0] + '\n'
    title = '旺旺分流告警:'
    if task == 'start':
        task_text = '开启助手优先\n'
    else:
        task_text = '开启人工优先\n'
    text = '{}未处理的店铺：\n{}\n处理失败的店铺：\n{}\n处理前已在特定状态的店铺：\n{}\n处理成功的店铺：\n{}'.format(task_text, dont_handle_text,
                                                                                 error_text,
                                                                                 warning_text, normal_text)
    logging.info('旺旺分流-店小蜜告警信息：{}'.format(text))
    utils.sendDingDingMessage(DingDingGroupURL, title, text)
    utils.sendDingDingMessage(DingDingInsideGroupURL, title, text)
    update_sql = """update shops set shop_service_status = 0"""
    csr.execute(update_sql)
    conn.commit()
    logging.info('已将店小蜜状态更新为0')


def clear_shop_service_status():
    clear_sql = """update shops set service_status = 0 """
    csr.execute(clear_sql)
    conn.commit()
    logging.info('已将店小蜜状态显示状态更新为0')


def clear_database():
    clear_sql = "DELETE FROM crawl_custom_service WHERE crawl_time < NOW()-INTERVAL 1 DAY"
    count = csr.execute(clear_sql)
    conn.commit()
    logging.info('已经删除两天前的数据，数据总量：{}'.format(count))


def run():
    logging.info('开始初始化环境')
    init_env()
    logging.info('初始化环境成功')
    sleep(1)
    schedule.every().day.at("23:40").do(send_shop_service_report, 'start')
    schedule.every().day.at("00:10").do(send_shop_service_report, 'close')
    # TODO 如果店小蜜全天运行，需要注释掉下面这行代码
    # schedule.every().day.at("00:21").do(clear_shop_service_status)
    schedule.every().day.at("00:01").do(clear_database)
    while True:
        # 获取所有店铺信息
        # 获取数据入库状况
        # 获取店铺需要的操作
        # 监控chrome 状态 TODO
        # 监控店小蜜报告
        # 检测循环是否需要结束
        shops_info = get_shops_info()
        shops = get_shops_data_time()
        # print('shops_info:', shops_info)
        # print('shops:', shops)
        for shop_info in shops_info:
            if shop_info[5] == 1:
                # print('is_active is 1, close shop start!')
                logging.warning('检测到已将店铺设置为关闭状态，开始关闭店铺，店铺：{}'.format(shop_info[0]))
                close_shop(shop_info)
                logging.info('店铺：{}，关闭成功！'.format(shop_info[0]))
                # print('is_active is 1, close shop end!')
            else:
                if shop_info[1] == 0:
                    logging.info('检测到店铺状态为开启，店铺状态为0，将开启店铺,{}'.format(shop_info[0]))
                    # print('is_active is 0,status is 0, start shop start!')
                    utils.upgrade_status(conn, csr, 1, shop_info[0])
                    sleep(1)
                    logging.warning('即将关闭店铺:{}'.format(shop_info[0]))
                    close_shop(shop_info)
                    sleep(1)
                    start_shop(shop_info)
                    sleep(1)
                    # print('is_active is 0,status is 0, start shop end!')
                elif shop_info[1] == 1:
                    pass
                    # print('is_active is 0,status is 1, pass!')
                elif shop_info[1] == 2:
                    # print('is_active is 0,status is 2, heartbeat start!')
                    # 数据未正常更新，重新启动
                    if shop_info[0] not in shops:
                        logging.info("检测到店铺未正常更新数据，即将关闭店铺，{}".format(shop_info[0]))
                        # print('is_active is 0,status is 2, shopname:', shop_info[0],
                        #       ' 数据未正常更新 restart，update status=0！')
                        close_shop(shop_info)
                        logging.info('已经关闭未正常更新数据的店铺，即将将店铺状态设置为0')
                        utils.upgrade_status(conn, csr, 0, shop_info[0])
                    # print('is_active is 0,status is 2, heartbeat end!')
                elif shop_info[1] == 3:
                    # print('is_active is 0,status is 3, pass!')
                    pass
                elif shop_info[1] == 4:
                    # print('is_active is 0,status is 4, pass!')
                    pass
                else:
                    # print('is_active is 0,status is other ???')
                    logging.error('检测到错误状态，店铺：{}'.format(shop_info[0]))
                    utils.screenshot_images(shop_info[0], '检测到错误状态')
        # 退出条件，所有店铺关闭,此时所有子进程关闭，主进程结束循环，程序退出
        if not close_main():
            logging.info('检测到所有店铺已经设置为关闭，循环监测程序将退出')
            break
        schedule.run_pending()
        sleep(10)


def init_env():
    # init_start_sql = """update shops set shop_status = 0,is_active = 0 ,handle = null ,chrome_pid = null ,manger_pid = null,refresh_time=now(),shop_service_status = 0 where is_start = 0"""
    init_start_sql = """update shops set shop_status = 0,is_active = 0 , refresh_time=now(),shop_service_status = 0 ,service_status = 0 where is_start = 0"""
    csr.execute(init_start_sql)
    logging.info('初始化更新所有设置为开启的shop_status，handle,chrome_pid,manger_pid,refresh_time,sql语句为：{}'.format(init_start_sql))
    # print(init_start_sql)
    # init_close_sql = """update shops set shop_status = 4,is_active = 1,handle = null ,chrome_pid = null ,manger_pid = null,refresh_time=now(),shop_service_status = 0 where is_start = 1"""
    init_close_sql = """update shops set shop_status = 4,is_active = 1,refresh_time=now(),shop_service_status = 0,service_status = 0  where is_start = 1"""
    csr.execute(init_close_sql)
    logging.info('初始化更新所有设置为关闭的shop_status，handle,chrome_pid,manger_pid,refresh_time,sql语句为：{}'.format(init_close_sql))
    # print(init_close_sql)
    conn.commit()


def get_shops_count():
    get_shops_count_sql = """select count(1) from shops"""
    csr.execute(get_shops_count_sql)
    shops_count = csr.fetchone()
    return shops_count[0]


class TaoLogin():

    def __init__(self, shop_info, shopname, port):
        self.shop_info = shop_info
        self.shopname = shopname
        self.port = port
        logging.info('init 初始化完成获取到的店铺为：{}，端口为{}'.format(self.shopname, self.port))

    def update_chrome_info(self, handle, chrome_pid):
        update_chrome_hande_sql = """update shops set handle = {},chrome_pid = {},refresh_time=now() where shopname = '{}'""".format(
            handle, chrome_pid, self.shopname)
        csr.execute(update_chrome_hande_sql)
        conn.commit()

    def close_before_chrome(self):
        select_sql = "select handle from shops where shopname = '{}'".format(self.shopname)
        csr.execute(select_sql)
        chrome_handle = csr.fetchone()
        if chrome_handle:
            try:
                ctypes.windll.user32.PostMessageA(chrome_handle[0], 0x0010, 0, 0)
            except Exception as e:
                print(e)
                pass
            sleep(2)

    @retry(tries=3, delay=2)
    def start_chrome(self):
        self.close_before_chrome()
        logging.info('已作关闭之前chrome处理，准备开始启动指定浏览器，店铺：{}'.format(self.shopname))
        access = '{} --user-data-dir="C:/wangwangfenliu/users/{}" --remote-debugging-port={}'.format(ACCESS,
                                                                                                     self.shop_info[7],
                                                                                                     self.port)
        logging.info('店铺：{}，启动参数：{}'.format(self.shopname, access))
        before_handle = get_all_chrome_handle()
        p = Popen(access)
        sleep(3)
        try:
            self.handle = self.check_chrome_start(before_handle)
            logging.info('店铺:{},获取到新的chrome窗口句柄为：{}'.format(self.shopname, self.handle))
            ctypes.windll.user32.ShowWindow(self.handle, 3)
            sleep(0.5)
            ctypes.windll.user32.SetForegroundWindow(self.handle)
            sleep(1)
            self.update_chrome_info(self.handle, p.pid)
            self.check_page_error()
        except Exception as e:
            logging.error('店铺：{}，启动chrome失败，错误信息：{}'.format(self.shopname, e))
            utils.screenshot_images(self.shopname, '启动chrome失败')
            p.kill()

    def close_error_page(self):
        sleep(1)
        pyautogui.move(900,900)
        rect = pyautogui.locateOnScreen('./images/error_page_btn.png', confidence=0.9)
        if rect:
            x = int((rect[0] * 2 + rect[2]) / 2)
            y = int((rect[1] * 2 + rect[3]) / 2)
            pyautogui.click(x, y)
            sleep(0.3)
            return True
        else:
            return False

    @staticmethod
    def get_new_handle(before_handle):
        after_handle = get_all_chrome_handle()
        for handle in after_handle:
            if handle not in before_handle:
                return handle
        return None

    @timeout(seconds=30)
    def check_chrome_start(self, before_handle):
        while True:
            sleep(1)
            handle = self.get_new_handle(before_handle)
            if handle:
                if self.close_error_page():
                    sleep(1)
                    return self.get_new_handle(before_handle)
                else:
                    return handle

    @timeout(seconds=30)
    def wait_load_ok(self):
        while True:
            sleep(1)
            self.check_focus_page()
            self.check_page_error()
            self.close_error_page()
            if not self.check_login_ok():
                return True
            rect = pyautogui.locateOnScreen('./images/login_btn.png', region=(1150, 200, 400, 400), confidence=0.8)
            if not rect:
                sleep(1)
            else:
                sleep(1)
                return False

    def click_login_orgin(self):
        # 1175,275
        self.check_focus_page()
        rect = pyautogui.locateOnScreen('./images/login_orgin.png', region=(1150, 200, 400, 400), confidence=0.8)
        pyautogui.click(rect[0] + 25, rect[1] + 38)
        sleep(1)
        pyautogui.click(rect[0], rect[1])
        sleep(1)

    def check_span(self):
        self.check_focus_page()
        return pyautogui.locateOnScreen('./images/span.png', region=(1150, 200, 400, 400), confidence=0.8)

    def check_move_span_ok(self):
        self.check_focus_page()
        return pyautogui.locateOnScreen('./images/span_ok.png', region=(1150, 200, 400, 400), confidence=0.8)

    def click_span_refresh(self):
        self.check_focus_page()
        rect = pyautogui.locateOnScreen('./images/span_refresh.png', region=(1150, 200, 400, 400), confidence=0.8)
        if not rect:
            raise Exception
        x = int((rect[0] * 2 + rect[2]) / 2)
        y = int((rect[1] * 2 + rect[3]) / 2)
        pyautogui.click(x, y)
        sleep(1)

    @retry(tries=5, delay=1)
    def move_span(self):
        if not self.check_login_ok():
            return
        pyautogui.hscroll(-100)
        sleep(0.3)
        # print('hsroll')
        sleep(1)
        self.check_focus_page()
        rect = pyautogui.locateOnScreen('./images/span.png', region=(1150, 200, 400, 400), confidence=0.8)
        x = int((rect[0] * 2 + rect[2]) / 2)
        y = int((rect[1] * 2 + rect[3]) / 2)
        pyautogui.moveTo(x, y, 0.5, pyautogui.easeInOutCirc)
        pyautogui.mouseDown(button='left', duration=uniform(0.05, 0.1))
        pyautogui.moveTo(x + 240, y + randint(-10, 10), uniform(0.5, 1.3), pyautogui.easeOutQuad)
        pyautogui.mouseUp(button='left', duration=uniform(0.05, 0.1))
        sleep(1)
        logging.info('拉动滑块结束，店铺：{}'.format(self.shopname))
        #  检测是否成功
        if not self.check_move_span_ok():
            logging.warning('拉动滑块失败，店铺：{}'.format(self.shopname))
            pyautogui.click(x, y)
            sleep(0.3)
            self.click_span_refresh()
            raise Exception
        sleep(1)
        logging.info('拉动滑块成功,店铺：{}'.format(self.shopname))

    @timeout(seconds=60 * 5)
    def warning_and_wait_people(self):
        title = '旺旺分流告警'
        text = '店铺:{},\n' \
               '时间:{},\n' \
               '登录需要短信验证，请及时处理'.format(self.shopname, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        utils.sendDingDingMessage(DingDingGroupURL, title, text)
        utils.sendDingDingMessage(DingDingInsideGroupURL, title, text)
        while self.check_login_ok():
            sleep(1)

    def check_msg(self):
        self.check_focus_page()
        rect = pyautogui.locateOnScreen('./images/msg_check.png', region=(1150, 200, 400, 400), confidence=0.8)
        if rect:
            logging.warning('点击登录按钮并等待3S之后出现短信验证框，将发送告警信息并等待人工处理，店铺：{}'.format(self.shopname))
            self.warning_and_wait_people()
        else:
            logging.info('点击登录按钮并等待3S之后没有出现短信验证框,店铺：{}'.format(self.shopname))
            sleep(1)

    def test_RGB(self, x, y, rgb, to=0):
        return pyautogui.pixelMatchesColor(int(x), int(y), rgb, tolerance=to)

    def check_focus_page(self):
        focus_handle = ctypes.windll.user32.GetForegroundWindow()
        if not focus_handle == self.handle:
            ctypes.windll.user32.SetForegroundWindow(self.handle)
            sleep(1)

    def check_login_ok(self):
        self.check_focus_page()
        return self.test_RGB(950, 110, (255, 255, 255), to=20)

    @timeout(seconds=30)
    def wait_login_ok(self):
        while self.check_login_ok():
            sleep(1)
        logging.info('点击登录按钮3S后，等待页面跳转完成，店铺：{}'.format(self.shopname))
        sleep(1)

    def get_login_btn_locate(self):
        self.check_focus_page()
        login_locate = pyautogui.locateOnScreen('./images/login_btn.png', region=(1150, 200, 400, 400), confidence=0.8)
        center_x = int((login_locate[0] * 2 + login_locate[2]) / 2)
        center_y = int((login_locate[1] * 2 + login_locate[3]) / 2)
        return center_x, center_y

    def check_login_btn(self):
        pyautogui.hscroll(-100)
        sleep(0.5)
        rect = pyautogui.locateOnScreen('./images/login_btn.png', region=(1150, 200, 400, 400), confidence=0.8)
        if rect:
            logging.error('等待3S后登录按钮仍然在页面上,将结束本次登录，店铺：{}'.format(self.shopname))
            utils.screenshot_images(self.shopname,'等待3S后登录按钮仍然在页面上')
            raise Exception

    def check_page_error(self):
        if self.test_RGB(1000, 25, (255, 255, 255), 10) and self.test_RGB(1200, 25, (255, 255, 255), 10):
            page_error_btn = pyautogui.locateOnScreen('./images/page_error.png', region=(1800, 0, 150, 150),
                                                      confidence=0.8)
            center_x = int((page_error_btn[0] * 2 + page_error_btn[2]) / 2)
            center_y = int((page_error_btn[1] * 2 + page_error_btn[3]) / 2)
            pyautogui.click(center_x, center_y)
            sleep(1)

    @retry(tries=3, delay=2)
    def parse_login(self):
        pyautogui.press('f5')
        if not self.check_login_ok():
            logging.info('检测到店铺已经进入到生意参谋主页，无需作登录操作，店铺：{}'.format(self.shopname))
            return
        logging.info('开始处理店铺，刷新,店铺：{}'.format(self.shopname))
        if self.wait_load_ok():
            return
        logging.info('页面加载完成，店铺：{}'.format(self.shopname))
        # print('page load ok')
        self.click_login_orgin()
        logging.info('点击login用户名和登录框,店铺：{}'.format(self.shopname))
        # print('click login orgin')
        sleep(1)
        if self.check_span():
            logging.warning('检测到滑块，店铺：{}'.format(self.shopname))
            self.move_span()
            logging.info('拉动滑块成功，店铺：{}'.format(self.shopname))
            x1, y1 = self.get_login_btn_locate()
            pyautogui.click(x1, y1)
        else:
            x2, y2 = self.get_login_btn_locate()
            logging.info('')
            pyautogui.click(x2, y2)
            sleep(1)
            if self.check_span():
                logging.warning('点击登录按钮后，检测到滑块，店铺：{}'.format(self.shopname))
                self.move_span()
                logging.info('点击登录按钮后，拉动滑块成功，店铺：{}'.format(self.shopname))
                x3, y3 = self.get_login_btn_locate()
                pyautogui.click(x3, y3)
        # print('click ok')
        logging.info('登录页处理前半部分完成，开始等待页面跳转店铺：{}'.format(self.shopname))
        sleep(3)
        if self.check_login_ok():
            logging.info('检测到等待3S后仍然未跳转到生意参谋主页面，将开始检测登录按钮，短信验证或页面加载缓慢逻辑，店铺：{}'.format(self.shopname))
            self.check_login_btn()
            logging.info('检测到等待3S后未检测到登录按钮，店铺：{}'.format(self.shopname))
            self.check_msg()
            # print('start wait')
            self.wait_login_ok()
            # print('login ok')

    def restore_chrome(self):
        chrome_store = Win32Window(self.handle)
        chrome_store.moveTo(0, 800)
        sleep(1)

    def run(self):
        logging.info('登录程序，开始初始化chrome，店铺：{}'.format(self.shopname))
        self.start_chrome()
        logging.info('登录初始化成功，开始处理登录过程，店铺：{}'.format(self.shopname))
        self.parse_login()
        logging.info('登录处理成功，店铺：{}'.format(self.shopname))
        sleep(1)
        # try:
        #     self.restore_chrome()
        #     logging.info('已将店铺移动到800，0，店铺：{}'.format(self.shopname))
        # except Exception as e:
        #     logging.error('店铺窗口移动失败，店铺：{}，错误信息：{}'.format(self.shopname, e))
        pyautogui.hotkey('win', 'd')
        logging.info('使用快捷键‘win’,‘d’将页面最小化，店铺：{}'.format(self.shopname))
        sleep(1)


if __name__ == '__main__':
    pyautogui.hotkey('win', 'd')
    sleep(0.3)
    conn, csr = utils.init_db()
    shops_count = get_shops_count()
    logging.info('获取到的店铺数量为{}'.format(shops_count))
    pool = Pool(int(shops_count) + 10)
    logging.info('已创建进程池，开始运行')
    run()
    pool.close()
    pool.join()
    csr.close()
    conn.close()
    logging.info('管理进程关闭')
