# -*- coding:utf-8 -*-
# ! python3

import re
import json
import requests
import time
from time import sleep

import settings
import utils
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import schedule
import logging
from timeout3 import timeout
from datetime import datetime
from retry import retry

logging.getLogger("requests").setLevel(logging.WARNING)
logging.getLogger("schedule").setLevel(logging.WARNING)


class Spider():

    def __init__(self, shopname, port):
        # print('start:', shopname, 'port:', port)
        self.shopname = shopname
        self.port = port
        self.conn, self.csr = utils.init_or_db()
        logging.info('爬虫进程开始，店铺：{}，端口：{}'.format(self.shopname, self.port))

    @timeout(seconds=60 * 30)
    def wait_page_login(self):
        while 'login' in self.driver.current_url:
            sleep(5)
        sleep(5)

    def init_env(self):
        chrome_options = Options()
        chrome_options.add_experimental_option("debuggerAddress", "127.0.0.1:{}".format(self.port))
        self.driver = webdriver.Chrome(chrome_options=chrome_options)
        # print(self.shopname, 'link_ok')
        logging.info('连接浏览器成功，店铺：{}'.format(self.shopname))
        self.driver.implicitly_wait(20)
        self.update_manger_pid()
        self.wait_page_login()
        self.driver.get(settings.MAIN_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)

    def update_manger_pid(self):
        manger_pid = os.getpid()
        update_sql = """update shops set manger_pid = {},start_time = now(),refresh_time=now() where shopname = '{}'""".format(
            manger_pid, self.shopname)
        self.csr.execute(update_sql)
        self.conn.commit()

    def __del__(self):
        self.upgrade_service_status(0)
        self.csr.close()
        self.conn.close()
        self.driver.close()

    def upgrade_status(self, status):
        log = settings.STATUS_LOG[status]
        upgrade_status_sql = "update shops set shop_status ={},log = '{}',refresh_time=now() where shopname = '{}'".format(
            status, log, self.shopname)
        self.csr.execute(upgrade_status_sql)
        # print(upgrade_status_sql)
        self.conn.commit()

    def check_logout(self):
        url = self.driver.current_url
        return 'login' in url

    def get_target(self):
        # 获取指标 4 个值
        indexes = {}
        page_showed_list = self.driver.find_elements_by_xpath('//*[@id="content"]/div[5]/div/div[1]/ul/li')
        if '-' in page_showed_list[0].find_element_by_xpath('./span[2]').text:  # 出现了横杠就重试一次
            raise ValueError('指标异常：页面尚未加载完成，5秒后重试抓取。')
        for one in page_showed_list:  # 共四个，三个整型一个浮点，还有可能出现字符
            key = one.find_element_by_xpath('./span[1]').text
            value = one.find_element_by_xpath('./span[2]').text
            if value.isdecimal():  # 前三个指标
                value = int(value)
            elif value.isalpha():  # 为“NaN”等非数字情况
                if key == '平均接待' and indexes['在线客服'] == 0:
                    value = 0.0
                else:
                    indexes[key] = value
                    raise ValueError('指标异常：'.format(indexes))
            else:  # 第四个指标，是个浮点
                value = round(float(value), 1)
            indexes[key] = value  # 添加键值对
        return indexes

    def get_servicers(self):
        _tb_token_ = re.findall(r'_tb_token_=((\d|\w)*)', self.driver.page_source)[0][0]
        account_status_url = 'https://zizhanghao.taobao.com/subaccount/qianniu/analysisAjaxHandler.htm?' \
                             'method=doGetAccountsStatus&_tb_token_={}&_tb_token_={}&site=0'
        cookies = {item["name"]: item["value"] for item in self.driver.get_cookies()}
        reponse = requests.get(
            account_status_url.format(_tb_token_, _tb_token_),
            cookies=cookies, timeout=5
        )
        data = json.loads(reponse.text)
        # 计算客服指标
        account_list = data['result']  # 当前店铺客服列表
        average_awaited_time_summery, average_responsed_time_summery, online_cnt = 0, 0, 0
        for a_account in account_list:
            if a_account['onlineStatus'] == 1:
                # print(a_account)
                average_awaited_time = a_account[
                    'averageAwaitedTime'] if 'averageAwaitedTime' in a_account else 0
                average_responsed_time = a_account[
                    'averageResponsedTime'] if 'averageResponsedTime' in a_account else 0
                average_awaited_time_summery += average_awaited_time
                average_responsed_time_summery += average_responsed_time
                online_cnt += 1
        return (average_awaited_time_summery, average_responsed_time_summery)

    def resolve_page(self):
        indexs = self.get_target()
        average_data = self.get_servicers()
        self.insert_to_database(indexs, average_data)

    def insert_to_database(self, indexes, average_data):
        cur_user = self.driver.find_element_by_xpath('//*[@id="site-nav-content"]/div[2]/a[1]').text
        data_capsule = (
            time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())),  # 时间戳
            cur_user,  # shop_id,
            self.shopname,  # 店铺名,
            indexes['当前买家'],  # 当前买家数
            indexes['在线客服'],  # 在线客服数
            indexes['挂起客服'],  # 挂起客服数",
            indexes['平均接待'],  # 平均接待数",
            average_data[0],  # 人均等待总时长,
            average_data[1],  # 人均响应总时长,
        )
        data_sql = str(data_capsule)
        cols = ["crawl_time", "shop_id", "shop_nick", "value1", "value2", "value3", "value4", "value5", "value6", ]
        cols_str = ','.join(cols)
        insert_data_sql = """insert into crawl_custom_service ({}) values {}""".format(cols_str, data_sql)
        self.csr.execute(insert_data_sql)
        self.conn.commit()

    @retry(tries=-1, delay=3)
    def task_get_data(self):
        self.driver.get(settings.MAIN_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(2)
        if self.check_logout():
            sleep(1)
            logging.error('检测到店铺退出登录，将更新店铺状态为0，店铺：{}'.format(self.shopname))
            utils.screenshot_images(self.shopname,'检测到店铺退出登录')
            self.upgrade_status(0)
            return Exception
        else:
            try:
                self.resolve_page()
            except:
                raise Exception
            sleep(10)
            self.upgrade_status(2)

    def check_load_page_ready(self):
        while True:
            try:
                self.driver.execute_script('window.scrollTo(0,100)')
                return
            except:
                sleep(1)

    def select_button(self, button=1):
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)
        select_xpath_str = "//div[@class='accept_model service_helper_item']/div[@class = 'helper_item_container']/div[{}]/input".format(
            button)
        self.driver.find_element_by_xpath(select_xpath_str).click()
        sleep(1)
        self.driver.find_element_by_xpath("//div[@class = 'section-group']/button").click()
        sleep(1)

    def check_action_success(self):
        get_text_xpath_str = "//div[@class = 'sui-msg msg-large msg-success']/div"
        text = self.driver.find_element_by_xpath(get_text_xpath_str).text
        return '成功' in text

    def double_check(self, button=1):
        self.driver.get(settings.MAIN_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)
        self.driver.get(settings.SHOP_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)
        select_xpath_str = "//div[@class='accept_model service_helper_item']/div[@class = 'helper_item_container']/div[{}]/input".format(
            button)
        return self.driver.find_element_by_xpath(select_xpath_str).is_selected()

    def upgrade_shop_service_status(self, status):
        # 更新店小蜜状态
        upgrade_sql = """update shops set shop_service_status = {} where shopname = '{}'""".format(status,
                                                                                                   self.shopname)
        self.csr.execute(upgrade_sql)
        self.conn.commit()

    def upgrade_service_status(self, status):
        upgrade_sql = """update shops set service_status = {} where shopname = '{}'""".format(status, self.shopname)
        self.csr.execute(upgrade_sql)
        self.conn.commit()

    def check_shop_service(self):
        # time_now = datetime.now()
        # time_range_start = datetime.strptime(str(datetime.now().date()) + '23:20', '%Y-%m-%d%H:%M')
        # time_range_end = datetime.strptime(str(datetime.now().date()) + '0:20', '%Y-%m-%d%H:%M')
        # if not (time_range_start < time_now < time_range_end):
        self.driver.get(settings.SHOP_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)
        self.check_load_page_ready()
        for i in range(1, 4):
            select_xpath_str = "//div[@class='accept_model service_helper_item']/div[@class = 'helper_item_container']/div[{}]/input".format(i)
            if self.driver.find_element_by_xpath(select_xpath_str).is_selected():
                self.upgrade_service_status(i)
                return

    def task_start_shop_service(self):
        # 开启店小秘操作
        self.upgrade_status(3)
        self.driver.get(settings.SHOP_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)
        self.check_load_page_ready()
        if self.double_check(2):
            self.upgrade_shop_service_status(2)
            return
        sleep(1)
        self.select_button(2)
        if not self.check_action_success():
            self.upgrade_shop_service_status(3)
            return
        if not self.double_check(2):
            self.upgrade_shop_service_status(3)
            return
        self.upgrade_shop_service_status(1)

    def task_close_shop_serice(self):
        # 关闭店小蜜操作
        self.upgrade_status(3)
        self.driver.get(settings.SHOP_URL)
        self.driver.execute_script('window.scrollTo(0,100)')
        sleep(1)
        self.check_load_page_ready()
        sleep(1)
        if self.double_check(1):
            self.upgrade_shop_service_status(5)
            return
        self.select_button(1)
        if not self.check_action_success():
            self.upgrade_shop_service_status(6)
            return
        if not self.double_check(1):
            self.upgrade_shop_service_status(6)
            return
        self.upgrade_shop_service_status(4)

    def test_task(self):
        url_list = ['https://www.baidu.com/', 'https://www.jd.com/', 'https://www.taobao.com/']
        for url in url_list:
            self.driver.get(url)
            self.driver.execute_script('window.scrollTo(0,100)')
            sleep(3)

    def re_connect_database(self):
        self.csr.close()
        self.conn.close()
        sleep(5)
        self.conn, self.csr = utils.init_or_db()
        sleep(2)

    def run(self):
        try:
            self.init_env()
            # 每60S做一次获取数据任务
            schedule.every(60).seconds.do(self.task_get_data)
            # schedule.every(10).seconds.do(self.test_task)
            # 在23：30 做一次开启店小蜜操作
            schedule.every().day.at("23:30").do(self.task_start_shop_service)
            # 在00：05 做一次关闭店小蜜操作
            schedule.every().day.at("00:05").do(self.task_close_shop_serice)
            # 每3min做一次获取店小蜜状态操作
            schedule.every(3).minutes.do(self.check_shop_service)
            # 每 两小时重新获取一次数据库连接
            schedule.every(2).hours.do(self.re_connect_database)
            logging.info('设置任务队列成功，店铺：{}'.format(self.shopname))
            while True:
                sleep(2)
                schedule.run_pending()
        except Exception as e:
            # print(e)
            logging.error('店铺爬虫进程出现错误，店铺：{}，错误原因：{}'.format(self.shopname, e))
            utils.screenshot_images(self.shopname,'店铺爬虫进程出现错误')
            self.upgrade_status(0)
            raise Exception
