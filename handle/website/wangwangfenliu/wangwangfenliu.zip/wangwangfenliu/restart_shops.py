# -*-coding:utf8-*-

import utils
import ctypes
from pywinauto.findwindows import find_windows
from time import sleep
from subprocess import Popen


def close_all_chrome():
    handles = find_windows(class_name='Chrome_WidgetWin_1')
    if handles:
        for handle in handles:
            ctypes.windll.user32.PostMessageA(handle, 0x0010, 0, 0)
            sleep(0.1)


def get_pids():
    get_info_sql = "select chrome_pid,manger_pid from shops"
    csr.execute(get_info_sql)
    for shop_info in csr.fetchall():
        utils.close_process(shop_info[0])
        utils.close_process(shop_info[1])
        sleep(0.1)


def update_status():
    update_sql = "update shops set is_active = 0, shop_status = 4"
    csr.execute(update_sql)
    conn.commit()


def start_manger():
    Popen('python C:/wangwang/code/manger.py')


if __name__ == '__main__':
    conn, csr = utils.init_or_db()
    update_status()
    close_all_chrome()
    get_pids()
    print('正在关闭所有相关进程')
    sleep(30)
    print('正在重新启动中，请稍后！')
    start_manger()
