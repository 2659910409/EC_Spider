# *-coding:utf8-*

# MSSQL 数据库配置
MYSQL_CONFIG = {'host': '128.71.100.132', 'port': 3306, 'user': 'root', 'password': 'root', 'database': 'wangwang_dev',
                'charset': 'utf8'}

# create_engine mysql地址
MYSQL_LINK_STR ="mysql+pymysql://root:root@128.71.100.132:3306/wangwang_dev?charset=utf8mb4"

# 取数URL
MAIN_URL = 'https://zizhanghao.taobao.com/subaccount/qianniu/realTime.htm'

# 店小蜜URL
SHOP_URL = 'https://zizhanghao.taobao.com/subaccount/qianniu/setting.htm'

# 启动参数设置
# "chrome.exe" --profile-directory="Profile 1001" --remote-debugging-port=9222 --user-data-dir="C:\wangwangfenliu\users"  --start-maximized  https://zizhanghao.taobao.com/subaccount/qianniu/realTime.htm
# 代理地址

# ACCESS = '"chrome" --proxy-server=172.16.50.75:8080 --start-maximized https://sycm.taobao.com/portal/home.htm'
ACCESS = '"chrome" --start-maximized https://sycm.taobao.com/portal/home.htm'

# 状态对应信息
STATUS_LOG = {0: '等待启动', 1: '正在启动', 2: '正常运行', 5: '异常结束', 4: '手动结束', 3: '店小秘操作'}

# 钉钉告警url
DingDingGroupURL = 'https://oapi.dingtalk.com/robot/send?access_token=906d7b2f4a4207bb0e649d6486aa27746d1448b880c3dad04ad3aa3709a517d9'

# 钉钉告警url
DingDingInsideGroupURL = 'https://oapi.dingtalk.com/robot/send?access_token=b65e1a4b8830dcde33c49c0b1ea559263d46eb6f0797dfff24cb2f662888a78a'

# 店小蜜状态
SHOP_SERVICES = {0: '初始状态', 1: '正常开启助手优先', 2: '助手在之前已经开启', 3: '开启助手优先失败', 4: '正常开启人工优先', 5: '人工优先在之前已经开启',
                 6: '人工优先开启失败'}

# 错误页面截图地址
ERROR_IMAGES_DIR = "C:/wangwangfenliu/error_images/"