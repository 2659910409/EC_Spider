# -*-coding:utf8-*-
import utils

if __name__ == '__main__':

    conn,csr = utils.init_db()
    close_sql = "update shops set is_active = 1"
    csr.excute(close_sql)
    csr.close()
    conn.close()
